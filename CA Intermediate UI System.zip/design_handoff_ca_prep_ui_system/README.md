# Handoff: Adhyayan — CA Exam-Prep UI System (CA Intermediate launch)

## Overview
A flexible UI **system** (tokens → components → page templates) for a free exam-prep website for Indian CA students, launching with CA Intermediate and built to expand (more levels, new tools, blog/updates). Brand feel: calm, trustworthy, studious — "a well-organized library run by a kind senior." No countdown pressure, no streak guilt, no gamification.

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code. Recreate them in the target codebase's environment (React/Next, Vue, etc.) using its established patterns. If no codebase exists yet, choose an appropriate stack (SSR/static-first strongly recommended — users are on budget Android phones with patchy data).

## Fidelity
**High-fidelity.** Colors, type sizes, spacing, radii, and copy are final. Recreate pixel-perfectly. (Each file is a canvas of labeled artboards; the artboard frames/labels themselves are presentation chrome, not product UI.)

## Hard product rules (enforced by the system)
- One primary action per screen. Plain-language labels ("Practice this chapter").
- Semantic color is NEVER alone — always paired with a glyph + word (✓ Correct, ✕ Incorrect, ! warning). Colorblind-safe.
- Ad slots: fixed height (never shift layout), labeled "ADVERTISEMENT", placed only between content sections. NEVER inside quiz question/feedback flow, never in the reading measure, never in the dashboard review queue. Empty state: dashed border, muted "Ads keep Adhyayan free".
- Trust metadata row on every content page: "✓ Verified for Sept 2026 attempt · Updated {date} · Source: {ref} · Report an error". Unreviewed content gets a "✎ Community draft" badge (amber).
- Rigid hierarchy Level → Paper → Chapter → Topic with persistent breadcrumbs (mobile truncates to "… › last two").
- Mastery states (Not started → Familiar → Proficient → Mastered) shown as 3 small segments + text label. Informative, never judgmental copy.
- Accessibility: WCAG 2.2 AA contrast, 44px+ touch targets, works at 320px, keyboard navigable, respect prefers-reduced-motion. System fonts only (zero font download).

## Design Tokens

### Color — Light (default)
| Token | Hex |
|---|---|
| bg / page | #F2EDE2 |
| surface / card | #FBF8F0 |
| surface-2 / inset | #EAE3D2 |
| row-alt | #F6F2E7 |
| border | #DCD3BF |
| border-strong | #B9AE94 |
| progress track | #E0D9C6 |
| header / ink bar | #232B3A (nav bars; text on it #F2EDE2, muted #A9B0C0, hairlines rgba(255,255,255,0.22), active pill rgba(255,255,255,0.14)) |
| text (ink) | #241E15 |
| text-2 | #5A5140 |
| text-3 (muted, large only) | #847860 |
| accent (the one action color) | #2E4770 (hover #243A5E, on-accent text #F5F3EA) |
| accent-tint | #E3E8F2 (border #C5CFE1) |
| correct | #3F7248 / tint #E4EEDF / border #C8D5B9 / text #2E5430 |
| incorrect | #AF4A30 / tint #F5E5DE / border #E5C2B3 / text #8E3A26 |
| warning / amendment | #8A6100 / tint #F5ECD7 / border #E4D5AC / text #6E4E00 |
| info / link-out | #3A5F8A / tint #E5EBF3 / border #C8D5E4 / text #2E4C6E |

### Color — Dark (night study)
bg #16130E · surface #201C16 · surface-2 #2A251C · borders #3A3428 / #4A4334 · text #EAE3D6 · text-2 #B0A895 · text-3 #857D6C · accent #A3B8E0 (tint #262E40, border #38445E, on-accent #1A2233) · correct #8FC7A3 / #22322A / #34493D · incorrect #E09A88 / #3A241F / #55352D · warning #D9B45C / #36301F / #4E442A · info #93B4D9 / #222B36.

### Type (system stack, no webfont)
`system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", Arial, sans-serif`
display 30/1.25 w700 (-0.01em) · h1 24/1.3 w700 · h2 20–22/1.35–1.4 w650–700 · reading body 17/1.7 (~65–75ch measure, max 640px column) · UI 16/1.5 · meta 13–14/1.5 · overline labels 12–13 w700 uppercase +0.06em. Numbers ALWAYS `font-variant-numeric: tabular-nums`, ₹ lakh-style grouping (2,40,000). Larger-text mode (A/A+ toggle in header) scales reading body up one step.

### Space / radius / elevation
Spacing scale: 4, 8, 12, 16, 24, 32, 48, 64. Radii: 6 (controls), 8 (buttons/callouts), 10 (cards), 999 (pills). Elevation: borders first; e-1 `0 1px 2px rgba(30,25,15,0.06)`, e-2 `0 4px 12px rgba(30,25,15,0.10)`.

## Components (see `01 Tokens and Components.dc.html`)
- **Buttons**: primary (accent bg, 44–48px min-height, r-8, w600), secondary (1.5px border-strong outline), tertiary (accent underlined text), disabled (surface-2 bg, text-3). One primary per screen.
- **Badges** (pill, 13px w600, tint bg + 1px tint-border): ✓ Verified · {attempt}; ✎ Community draft (warning colors); 🔒 Requires ICAI login (info); Updated {date} (neutral); ! Amended (warning).
- **Callouts** (r-8, tint bg + tint border; header = 22px rounded glyph chip + uppercase 12px label): Worked example (accent blue, ✎, contains white "working note" sub-cards), Common mistake (incorrect red, ✕), Exam pointer (info blue, ★), Amendment alert (warning amber, !, old rule struck through).
- **Data table**: header row surface-2 13px w700, 15px rows, numeric columns right-aligned tabular-nums, total row heavy top border; horizontal scroll container on mobile.
- **Mastery indicator**: three 16×6px r-3 segments (filled = accent, empty = 1px border-strong outline) + label; "Mastered ✓" adds check. Progress bar: 6px track/accent fill + "18 of 24 topics" text.
- **Breadcrumbs** (14px, accent links, "›" separators), **tabs** (2px accent underline on active), **accordion** (chapter rows with mastery + ±), **banner** (dismissible, warning style), **empty state** (dashed border, gentle copy, one secondary action), **ad slot** (100px fixed height; see rules above).
- **Nav**: dark ink bar (#232B3A) with cream logo tile (अ) + wordmark; ≤5 sections inline, 6+ folds into "More ▾" menu. Mobile: bottom nav fixed at exactly Home / Papers / Practice / Dashboard (48px targets); extra sections live in a "Browse" sheet under Papers.

## Screens / Templates
1. **Hub template** (`02 …`): breadcrumb → overline (level/group/marks) → h1 → trust row → primary action + progress → tabs (Chapters/Practice/Resources) → sectioned list cards (56px rows: number, title, badges, mastery, ›) → ad slot between sections → resource directory (official ICAI links with ↗, "Last checked {date}", 🔒 login flag). Proven as Paper page AND future Mock-tests section — same anatomy, different content.
2. **Reading template** (`03 …`): 640px article column + 240px sticky "On this page" sidebar (2px left rule, accent for active) + "Your standing" card. Title → trust row → read-time → body with callouts → one ad slot between h2 sections → "Practice this topic" primary → prev/next cards. Mobile shown in dark mode.
3. **Quiz** (`04 …`): dark chrome bar (← Exit, "Question n of N", optional factual timed chip), 4px progress strip. Before: option rows (52px min, letter circle; selected = accent 2px border + tint). After: result banner (glyph + word + "Saved to your Mistake notebook"), EVERY option gets an explanation (correct = green 2px, chosen-wrong = red 2px "Your answer", others neutral), correct option links to the exact note section ("Read: §1 →"). Next question primary + "Open Mistake notebook" link. NO ads anywhere in this flow.
4. **Dashboard** (`05 …`): greeting + factual attempt line ("begins 8 Sept 2026 · 74 days from today · change attempt"); Today's review card (spaced repetition, "anything skipped simply waits", one primary "Start today's review"); ad slot BELOW the queue card; Recent mistakes list with Retry links; right rail: per-paper progress bars + calm "This week" facts ("A quiet week is fine. The queue adjusts to you.").

## Interactions & State
- Hover: primary → #243A5E; rows → row-alt bg; outline buttons → darker border. Focus: visible outline (2px accent offset 2px) on everything.
- Theme: light/dark toggle (☾/☀) in header, persisted; respect prefers-color-scheme initially. Text-size A/A+ toggle persisted.
- State needed: per-topic mastery (4 levels), per-paper % complete, review queue (due items), mistake notebook (auto-append on wrong answers), selected attempt (drives all "Verified for…" labels and countdown), quiz session (index, answers, elapsed if timed).
- Reduced motion: no transitions beyond opacity when set.

## Assets
No images/icon fonts. Logo = अ glyph in a rounded tile. Icons are unicode glyphs in the mocks (✓ ✕ ★ ✎ ! ⌂ ▤ ◔ ☾ ⌕) — replace with a lightweight inline SVG set (e.g. Lucide subset) at equal sizes; keep total icon payload tiny.

## Files in this bundle
- `00 Overview.dc.html` — index + system rules
- `01 Tokens and Components.dc.html` — tokens + component sheet (light & dark)
- `02 Hub Template and Navigation.dc.html` — hub ×2, nav at 4/8 items, mobile
- `03 Notes Reading Template.dc.html` — reading template desktop + dark mobile
- `04 Quiz Template.dc.html` — before/after states + mobile
- `05 Dashboard Template.dc.html` — desktop + mobile
- `06 Light Palette Options.dc.html` — palette exploration (option 1a "Ink & Paper" was chosen and applied; kept for context)

Open each file in a browser; artboards are labeled. The outer canvas backdrop (#E8E3D8) and monospace artboard labels are presentation chrome, not product UI.
